/* ENSF 614 - Lab 5 Exercise A
 * File Name: Component.java
 * M. Moussavi, October 2024
 * Lab Section: B01
 * Completed by: Jack Shenfield
 * Submission Date: November 4th, 2025
 */

import java.awt.Graphics;

public interface Component {

	void draw(Graphics g);
}
